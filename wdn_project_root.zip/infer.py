# infer.py
print('Inferencia ejecutada - placeholder')
