# WDN Project Root

Simulación, entrenamiento e inferencia de red neuronal para sistemas de distribución de agua.
