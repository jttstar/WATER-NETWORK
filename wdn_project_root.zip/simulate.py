# simulate.py
print('Simulación ejecutada - placeholder')
